#### Assignment solutions - Text Blob

**Question 1.** Write a python program using Textblob in which find out the parts-of-speech(pos) tagging from the following sentence.

"Susie works in a shoeshine shop. Where she shines she sits, and where she sits she shines"

```python
import nltk
from textblob import TextBlob
test=TextBlob("Susie works in a shoeshine shop. Where she shines she sits, and where she sits she shines")
test.tags
```

**Question 2.** What is Wordlist? And, how it is different than tokenization?

Wordlist in Text Blob, is nothing but a string list with the extracted words from the given input text. It is no different from tokenization. 

**Question 3.** Write a python program using the textblob to find out the count of the common words from the following sentence.

"How much wood would a woodchuck chuck if a woodchuck could chuck wood?
He would chuck, he would, as much as he could, and chuck as much wood
As a woodchuck would if a woodchuck could chuck wood"
Find it out how many times 'wood' came in the sentence.

```python
given_text=TextBlob("How much wood would a woodchuck chuck if a woodchuck could chuck wood?,He would chuck, he would, as much as he could, and chuck as much wood,As a woodchuck would if a woodchuck could chuck wood")

given_text.word_counts["wood"]
```

**Question 4.** Translate the following sentences in your own language using the textblob.

"Data is a new oil.", "A.I is the last invention", "She sells seashells by the seashore", "He threw three free throws".

```python
t1=TextBlob("Data is a new oil.")
t2=TextBlob("A.I is the last invention")
t3=TextBlob("She sells seashells by the seashore")
t4=TextBlob("He threw three free throws.")
text_list=[t1,t2,t3,t4]

for i in text_list:
    print("\n",i.translate(to='hi'))
    print(i.translate(to='ta'))
```

**Question 5.** Create a spell checker program using the textblob library with using your own sentences.

**Approach used** : A file named "1.txt" is created with 5 lines o f text. It is read line by line. Each line then converted to Text Blob and corrected for spelling using correct() method. the resultant sentences are then written to another file named "2.txt"



```python
nl=[]
f = open('1.txt', 'r+')
for line in f.readlines():
    
    l=[TextBlob(line)]
    
    for i in l:
        
        print("Actual text given : \n",i)
        print("Corrected text : \n",l[0].correct())    
        nl.append(str(l[0].correct()))
        
f.close()


with open('2.txt','w') as out:
    out.writelines(nl)
```

